<?php 
    header('Location: /');
?>